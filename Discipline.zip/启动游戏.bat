@echo off
cd /d "%~dp0"

call .venv\Scripts\activate
call pip install streamlit
start /b "" cmd /c "timeout /t 2 /nobreak > nul & start http://localhost:8501"
streamlit run Competition.py --server.headless true